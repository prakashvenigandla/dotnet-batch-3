using Microsoft.EntityFrameworkCore;
using MySql.EntityFrameworkCore;

public class ProductMgmtDbContext:DbContext
{
    public DbSet<Product> Products { get; set; }
    public ProductMgmtDbContext(DbContextOptions<ProductMgmtDbContext> options):base(options)
    {
        
    }
}
