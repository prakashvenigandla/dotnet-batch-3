using Microsoft.AspNetCore.Mvc;
using ProductCrudEfCoreMySqlDb.Models;

public class ProductsController:Controller
{
    private ProductMgmtDbContext productMgmtDbContext;
    public ProductsController(ProductMgmtDbContext productMgmtDbContext)
    {
     this.productMgmtDbContext=productMgmtDbContext;   
    }
    [HttpGet]
    public IActionResult Create()
    {
        return View();
    }
    [HttpPost]
    public IActionResult Create(Product product)
    {
    this.productMgmtDbContext.Add(product);    
    this.productMgmtDbContext.SaveChanges();
    return View("List",this.productMgmtDbContext.Products.ToList());   
    }
    public  IActionResult List()
    {
        return View(this.productMgmtDbContext.Products.ToList());
    }
}